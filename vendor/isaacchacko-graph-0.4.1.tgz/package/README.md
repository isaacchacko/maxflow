# @isaacchacko/graph

Pretty, living force-directed graphs from a few lines of text. Write `A -> B, C` and you get a graph that settles into place, responds to hover, drag, pan and zoom, and exports to PNG or SVG.

It is the renderer behind [graph.isaacchacko.com](https://graph.isaacchacko.com), packaged for your own pages. There are no runtime dependencies, and React is optional.

## Pick how you want to use it

### 1. No build step: one `<script>` and one tag

```html
<script src="https://unpkg.com/@isaacchacko/graph"></script>

<graph-view arrows>
  graph -> renderer, website
  renderer -> physics, camera, labels
  Sun {gold 3} -> Earth -> Moon
</graph-view>
```

The text inside the tag is the graph. Change it (or set `.source`) and the graph updates without reshuffling.

| Attribute | Values |
| --- | --- |
| `theme` | `auto` (default, follows the OS), `dark`, `light` |
| `arrows` | present to draw arrowheads |
| `mode` | `select` (default: drag nodes, pan) or `edit` (drag node→node to emit `connect`) |
| `no-zoom` | present to let the wheel scroll the page instead of zooming the graph |

Size it with CSS. It is `display: block; height: 400px` until you say otherwise.

```js
const el = document.querySelector("graph-view");
el.source = "x -> y -> z";                      // or el.data = { nodes, links }
el.options = { nodeSize: 1.5, forces: { repelForce: 14 } };
el.addEventListener("nodeClick", (e) => console.log(e.detail.id));
await el.renderer.toPNG();                      // the full renderer API
```

The same script also exposes everything below as `window.GraphView`.

### 2. React

```sh
npm i @isaacchacko/graph
```

```tsx
import { Graph } from "@isaacchacko/graph/react";

<Graph source={"A -> B, C\nB -> C"} theme="light" onNodeClick={({ id }) => alert(id)} />;
```

| Prop | |
| --- | --- |
| `source` | the graph language as a string |
| `data` | `{ nodes, links }` instead of `source` |
| `theme` | `"dark"`, `"light"` or a partial `Theme` |
| `options` | any renderer option (see below) |
| `highlighted` | node ids to emphasise, e.g. search matches |
| `selection` | a node, nodes or link to draw as selected |
| `onReady` | receives the `GraphRenderer` for exports, zoom, replay… |
| `onNodeClick`, `onConnect`, … | every renderer event, as `on` + its name |
| `className` / `style` | without either it fills the width and is 400px tall |

It works in Next.js server-component trees as is (it ships `"use client"`).

### 3. Web component in a bundler (Vue, Svelte, Astro, plain TS…)

```ts
import "@isaacchacko/graph/element"; // registers <graph-view>
```

### 4. Plain TypeScript

```ts
import { GraphRenderer, parseGraph, LIGHT_THEME } from "@isaacchacko/graph";

const graph = new GraphRenderer(document.getElementById("graph")!, { theme: LIGHT_THEME, arrows: true });
graph.setData(parseGraph("A -> B -> C").data);
// or graph.setData({ nodes: [{ id: "a" }, { id: "b", color: "tomato", size: 2 }], links: [{ source: "a", target: "b" }] });

graph.on("nodeClick", ({ id }) => console.log(id));
const svg = graph.toSVG();
const png = await graph.toPNG({ transparent: true });
graph.destroy();
```

The container must have a size; the canvas fills it and follows it as it resizes.

### 5. At build time, or on a server

No browser needed: `settle` lays a graph out with the renderer's own physics, and `renderSvg` draws it.

```ts
import { parseGraph, renderSvg, settle } from "@isaacchacko/graph";

const svg = renderSvg(parseGraph("A -> B -> C").data, { arrows: true }); // lays it out first if it has no positions

// Or settle once, ship the SVG for the first paint, then hand the same layout to the
// live renderer in the browser, which starts from it instead of unfolding from scratch.
const laidOut = settle(parseGraph(source).data);
const picture = renderSvg(laidOut, { theme: { background: null, node: "var(--ink, #333)" } });
```

In SVG output, theme colours can be CSS variables, so the page's stylesheet themes the picture.

### 6. Just an iframe

Make a graph at [graph.isaacchacko.com](https://graph.isaacchacko.com), open *Export & share*, and press *Copy embed code* (an `<iframe>`) or *Copy embed link* (its URL, for anything that frames links itself). You can also write the URL by hand:

```html
<iframe src="https://graph.isaacchacko.com/embed?source=A%20-%3E%20B%2C%20C&theme=paper&arrows"
        width="100%" height="400" style="border:0"></iframe>
```

The embed draws only the canvas, framed to fit and refitted as the iframe resizes, with a small *graph ↗* link that opens it in the editor. It never writes to storage or history, so it can't touch a visitor's own saved graph. `?theme=<id>` overrides the graph's theme (`vault`, `paper`, `midnight`, `rose`, `forest`, `blueprint`, `ink`); `?theme=auto` follows the page's light or dark, keeping the graph's theme when it suits and otherwise using Paper or Vault. `auto` reads the visitor's system setting, so it can't see a page's own theme toggle. `?no-zoom` lets the wheel scroll the page around a graph instead of zooming it.

## The language

| Syntax | Meaning |
| --- | --- |
| `A -> B` | link (`<-` reverses, `--` undirected, `<->` both ways) |
| `A -(3)-> B` | weighted link, shown at its midpoint (works on every arrow) |
| `A -> B, C` | fan out |
| `A -> B -> C` | chain |
| `A {red 2}` | colour and size, wherever the node appears |
| `"Acme, Inc."` | quote names containing `,` `{` `}` or arrows |
| `# …` / `// …` | comments |

`parseGraph(text)` returns `{ data, errors }` (plus source spans, for editors), with `errors` as `{ line, message }[]`. A bad line is skipped and the rest of the graph still renders.

## Renderer API

| Method | |
| --- | --- |
| `new GraphRenderer(container, options?)` | creates the canvas inside `container` |
| `setData({ nodes, links })` | keeps positions of nodes that survive, seeds new ones next to a neighbour |
| `setOptions(partial)` | any option below; forces and theme merge |
| `on(event, fn)` | returns an unsubscribe function |
| `zoomToFit()`, `zoomBy(factor)`, `panTo(id)` | camera |
| `replay(ms?)` | rebuilds the graph node by node |
| `reheat(alpha?)` | shakes the layout loose |
| `setHighlighted(ids \| null)`, `setSelection(sel)` | emphasis |
| `toPNG(opts?)`, `toSVG(opts?)` | exports cropped to the graph |
| `settle(data, forces?)`, `renderSvg(data, options?, exportOptions?)` | functions, not methods: layout and SVG without a DOM |
| `setInsets({ top, right, bottom, left })` | keeps framing clear of overlaid UI |
| `createModeToolbar(renderer, { onChange?, keys?, tips? })` | a function: the site's select/edit toggle without React; place its `element` over the graph. S and E switch modes unless `keys: false` |
| `destroy()` | removes the canvas and listeners |

**Options**: `theme` (`background`, `node`, `link`, `text`, `accent`, `fontFamily`), `forces` (`centerForce`, `repelForce`, `linkForce`, `linkDistance`), `nodeSize`, `linkThickness`, `textSize`, `arrows`, `mode`, `zoom`, `textFadeThreshold`, `dimOpacity`.

**Node fields**: `id`, `label`, `color`, `size`, `x`, `y`, `icon` (an image URL, or several to try in turn, drawn inside the node ringed in its color; a dark icon on a dark theme gets a light plate when its pixels are readable, i.e. same-origin or CORS). **Link fields**: `source`, `target`, `label`, `length`, `hidden` (pulls its ends together without being drawn).

**Events**: `nodeClick`, `nodeDoubleClick`, `nodeHover`, `linkClick`, `backgroundClick`, `backgroundDoubleClick`, `connect`, `boxSelect`, `nodeContextMenu`, `linkContextMenu`, `zoom`.

## License

MIT
